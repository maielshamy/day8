import React from "react";

const Signup = () => {
  return (
    <div className="sign" style={{ textAlign: "center" }}>
      <h1>WELCOME TO MY HOME PAGE</h1>
    </div>
  );
};

export default Signup;
